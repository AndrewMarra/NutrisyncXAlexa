/* *
 * This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
 * Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
 * session persistence, api calls, and more.
 * */
 
 
 
const Alexa = require('ask-sdk-core');


const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        //access Your environment variables
        const app_id = process.env.app_id
        const api_key = process.env.app_key
        
        const speakOutput = 'Hello, and welcome to Alexa NutriSync. What would you like to do today!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const StartCalorieTrackingIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'StartCalorieTrackingIntent';
    },
    handle(handlerInput) {
        // Initialize or reset the calorie count to 0 in the session attributes.
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = attributesManager.getSessionAttributes();
        sessionAttributes.caloriesConsumed = 0;
        attributesManager.setSessionAttributes(sessionAttributes);

        const speakOutput = 'Okay, let\'s start tracking your calories. Please tell me the calories you consume, and I will add them up.';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const SetDailyCalorieGoalIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SetDailyCalorieGoalIntent';
    },
    handle(handlerInput) {
        const { requestEnvelope, attributesManager } = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();

        // Get the calorie goal from the user's input.
        const calorieGoal = Alexa.getSlotValue(requestEnvelope, 'calorieGoal');

        if (!calorieGoal || isNaN(calorieGoal)) {
            const speakOutput = 'I couldn\'t understand the calorie goal. Please try again.';
            return handlerInput.responseBuilder
                .speak(speakOutput)
                .reprompt(speakOutput)
                .getResponse();
        }

        // Store the calorie goal in the session attributes.
        sessionAttributes.calorieGoal = parseFloat(calorieGoal);
        attributesManager.setSessionAttributes(sessionAttributes);

        const speakOutput = `Your daily calorie goal has been set to ${calorieGoal} calories.`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('You can start tracking your calories or ask for help.')
            .getResponse();
    },
};

const AddCaloriesIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AddCaloriesIntent';
    },
    async handle(handlerInput) {
        const { requestEnvelope, attributesManager } = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();

        // Get the food item and quantity from the user's input.
        const foodItem = Alexa.getSlotValue(requestEnvelope, 'foodItem');
        const quantity = Alexa.getSlotValue(requestEnvelope, 'quantity');

        if (!foodItem || !quantity || isNaN(quantity)) {
            const speakOutput = 'I couldn\'t understand the food item or quantity. Please try again.';
            return handlerInput.responseBuilder
                .speak(speakOutput)
                .reprompt(speakOutput)
                .getResponse();
        }

        // Define a mapping of food items to their calorie content.
        const foodCalories = {
            'eggs': 78,
            'bacon': 43,
            'tuna': 32.5,
            'Hamburger': 250,
            'French Fries': 365,
            'Banana': 105,
            'Pizza': 285,
        };

        // Calculate the calories based on the food item and quantity.
        const calorieAmount = foodCalories[foodItem.toLowerCase()] * parseFloat(quantity);

        if (!calorieAmount || isNaN(calorieAmount)) {
            const speakOutput = 'I don\'t have calorie information for that food item. Please try a different one.';
            return handlerInput.responseBuilder
                .speak(speakOutput)
                .reprompt(speakOutput)
                .getResponse();
        }

        // Initialize caloriesConsumed to 0 if it's undefined
        if (sessionAttributes.caloriesConsumed === undefined) {
            sessionAttributes.caloriesConsumed = 0;
        }

        // Add the calorie amount to the total count.
        sessionAttributes.caloriesConsumed += calorieAmount;
        attributesManager.setSessionAttributes(sessionAttributes);

        const speakOutput = `You've consumed ${calorieAmount} calories by eating ${quantity} oz of ${foodItem}. Your total calorie count for today is ${sessionAttributes.caloriesConsumed} calories.`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('You can continue tracking your calories or ask for help.')
            .getResponse();
    }
};



const GetTotalCaloriesIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'GetTotalCaloriesIntent';
    },
    handle(handlerInput) {
        const { attributesManager } = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();
        const totalCalories = sessionAttributes.caloriesConsumed || 0;

        const speakOutput = `Your total calorie count for today is ${totalCalories} calories.`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('You can continue tracking your calories or ask for help.')
            .getResponse();
    }
};

const GetRemainingCaloriesIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'GetRemainingCaloriesIntent';
    },
    handle(handlerInput) {
        const { attributesManager } = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();

        const calorieGoal = sessionAttributes.calorieGoal || 0;
        const caloriesConsumed = sessionAttributes.caloriesConsumed || 0;

        // Calculate the remaining calories based on consumed calories and the goal.
        const remainingCalories = calorieGoal - caloriesConsumed;

        let speakOutput = '';

        if (remainingCalories > 0) {
            speakOutput = `You have ${remainingCalories} calories left to consume today.`;
        } else if (remainingCalories === 0) {
            speakOutput = 'You have already reached your calorie goal for today.';
        } else {
            speakOutput = 'You have exceeded your calorie goal for today.';
        }

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('You can continue tracking your calories or ask for help.')
            .getResponse();
    },
};

const AddCustomCaloriesIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AddCustomCaloriesIntent';
    },
    handle(handlerInput) {
        const { requestEnvelope, attributesManager } = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();

        // Get the manually entered calories from the user's input.
        const customCalories = Alexa.getSlotValue(requestEnvelope, 'calories');

        if (!customCalories || isNaN(customCalories)) {
            const speakOutput = 'I couldn\'t understand the calories you entered. Please try again with a valid number.';
            return handlerInput.responseBuilder
                .speak(speakOutput)
                .reprompt(speakOutput)
                .getResponse();
        }

        // Convert customCalories to a number.
        const caloriesToAdd = parseFloat(customCalories);

        // Initialize caloriesConsumed to 0 if it's undefined.
        if (sessionAttributes.caloriesConsumed === undefined) {
            sessionAttributes.caloriesConsumed = 0;
        }

        // Add the manually entered calories to the total count.
        sessionAttributes.caloriesConsumed += caloriesToAdd;
        attributesManager.setSessionAttributes(sessionAttributes);

        const speakOutput = `You've manually added ${caloriesToAdd} calories. Your total calorie count for today is now ${sessionAttributes.caloriesConsumed} calories.`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('You can continue tracking your calories or ask for help.')
            .getResponse();
    }
};



const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'You can say hello to me! How can I help?';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
/* *
 * FallbackIntent triggers when a customer says something that doesn’t map to any intents in your skill
 * It must also be defined in the language model (if the locale supports it)
 * This handler can be safely added but will be ingnored in locales that do not support it yet 
 * */
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Sorry, I don\'t know about that. Please try again.';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};
/* *
 * The intent reflector is used for interaction model testing and debugging.
 * It will simply repeat the intent the user said. You can create custom handlers for your intents 
 * by defining them above, then also adding them to the request handler chain below 
 * */
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};
/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Sorry, I had trouble doing what you asked. Please try again.';
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        StartCalorieTrackingIntentHandler,
        AddCaloriesIntentHandler,
        GetTotalCaloriesIntentHandler,
        SetDailyCalorieGoalIntentHandler,
        GetRemainingCaloriesIntentHandler,
        AddCustomCaloriesIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda();