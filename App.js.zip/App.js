import React, { Component } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ImageBackground,
  Image,
  ScrollView,
} from "react-native";
// App.js
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import "react-native-gesture-handler";
import AlexaScreen from "./alexascreen"; 
import { sendVoiceCommand } from "./voicehandler"; 

const Stack = createStackNavigator();
/*
function Alexa() {
  
  const handleVoiceCommand = async (voiceCommand) => {
    try {
      const response = await sendVoiceCommand(voiceCommand);
      
      console.log("Alexa Skill Response:", response);
    } catch (error) {
      
      console.error("Error:", error);
    }
  };

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        {// Define your app's navigation here }
        <Stack.Screen name="Home" component={AlexaScreen} />
        {//Add more screens and navigation options as needed }
      </Stack.Navigator>
    </NavigationContainer>
  );
}
*/

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      foodName: "",
      protein: "0", // Store protein, carbs, and fat as strings to prevent empty input issues
      carbs: "0",
      fat: "0",
      foodItems: [],
    };
  }

  handleVoiceCommand = async (voiceCommand) => {
    try {
      const response = await sendVoiceCommand(voiceCommand);
      
      console.log("Alexa Skill Response:", response);
    } catch (error) {
      
      console.error("Error:", error);
    }
  };

  handleAddFood = () => {
    const { foodName, protein, carbs, fat } = this.state;
    const parsedProtein = parseFloat(protein);
    const parsedCarbs = parseFloat(carbs);
    const parsedFat = parseFloat(fat);

    if (
      foodName &&
      !isNaN(parsedProtein) &&
      !isNaN(parsedCarbs) &&
      !isNaN(parsedFat)
    ) {
      const calories = parsedProtein * 4 + parsedCarbs * 4 + parsedFat * 9; // Calculate calories
      const newFoodItem = {
        name: foodName,
        protein: parsedProtein,
        carbs: parsedCarbs,
        fat: parsedFat,
        calories,
      };
      this.setState((prevState) => ({
        foodItems: [...prevState.foodItems, newFoodItem],
        foodName: "",
        protein: "0",
        carbs: "0",
        fat: "0",
      }));
    } else {
      
      alert("Please enter valid values for all fields.");
    }
  };

  calculateTotalMacros = () => {
    const { foodItems } = this.state;
    let totalProtein = 0;
    let totalCarbs = 0;
    let totalFat = 0;
    let totalCals = 0;

    foodItems.forEach((food) => {
      totalProtein += food.protein;
      totalCarbs += food.carbs;
      totalFat += food.fat;
      totalCals += food.protein * 4 + food.carbs * 4 + food.fat * 9;
    });

    return { totalProtein, totalCarbs, totalFat, totalCals };
  };

  render() {
    const { foodName, protein, carbs, fat, foodItems, cals } = this.state;
    const { totalProtein, totalCarbs, totalFat, totalCals } =
      this.calculateTotalMacros();

    return (
      <View style={styles.container}>
        <ImageBackground
          source={require("./food.webp")}
          style={styles.backgroundImage}
        >
          <ScrollView contentContainerStyle={styles.scrollContainer}>
          <Image source={require("./NutriSync.png")} style={styles.IMG}></Image>

            <View style={styles.inputContainer}>

              <View style={styles.inputRow}>
                <Text style={styles.label}>Food Name:</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Food Name"
                  onChangeText={(text) => this.setState({ foodName: text })}
                  value={foodName}
                />
              </View>
              <View style={styles.inputRow}>
                <Text style={styles.label}>Protein (g):</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Protein (g)"
                  onChangeText={(text) =>
                    this.setState({ protein: parseFloat(text) })
                  }
                  value={protein.toString()}
                />
              </View>
              <View style={styles.inputRow}>
                <Text style={styles.label}>Carbs (g):</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Carbs (g)"
                  onChangeText={(text) =>
                    this.setState({ carbs: parseFloat(text) })
                  }
                  value={carbs.toString()}
                />
              </View>
              <View style={styles.inputRow}>
                <Text style={styles.label}>Fat (g):</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Fat (g)"
                  onChangeText={(text) =>
                    this.setState({ fat: parseFloat(text) })
                  }
                  value={fat.toString()}
                />
              </View>

              <TouchableOpacity
                style={styles.button}
                onPress={this.handleAddFood}
              >
                <Text style={styles.buttonText}>Add Food</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.macroContainer}>
              <Text style={styles.macroLabel}>
                Total Protein (g): {totalProtein}
              </Text>
              <Text style={styles.macroLabel}>
                Total Carbs (g): {totalCarbs}
              </Text>
              <Text style={styles.macroLabel}>Total Fat (g): {totalFat}</Text>
              <Text style={styles.macroLabel}>
                Total Calories (kC): {totalCals}
              </Text>
            </View>
            <View style={styles.foodItemList}>
              {foodItems.map((food, index) => (
                <View key={index} style={styles.foodItem}>
                  <Text>{food.name}</Text>
                  <Text>Protein: {food.protein}g</Text>
                  <Text>Carbs: {food.carbs}g</Text>
                  <Text>Fat: {food.fat}g</Text>
                  <Text>Calories: {food.calories} kC</Text>
                </View>
              ))}
            </View>
          </ScrollView>
        </ImageBackground>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  backgroundImage: {
    flex: 1,
    resizeMode: "cover",
    width: "100%",
    height: "100%",
    position: "absolute",
    justifyContent: "center",
    alignItems: "center",
  },
  IMG: {
    width: 300,
    height: 100,
    resizeMode: "contain",
    marginBottom: 5,
  },
  title: {
    fontSize: 42,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
    color: "#5dc75d",
  },
  inputContainer: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10,
    elevation: 5,
    marginBottom: 20,
    height: 220,
    width: 300,
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },
  label: {
    flex: 1,
    fontSize: 16,
    marginRight: 10,
  },
  input: {
    flex: 2,
    borderBottomWidth: 1,
    borderBottomColor: "red",
    fontSize: 16,
    color: "black",
  },

  button: {
    backgroundColor: "#007bff",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
  },
  buttonText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "white",
  },
  macroContainer: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10,
    elevation: 5,
    marginBottom: 20,
  },
  macroLabel: {
    fontSize: 16,
    marginBottom: 10,
  },
  foodItemList: {
    alignItems: "center",
  },
  foodItem: {
    backgroundColor: "white",
    padding: 10,
    borderRadius: 5,
    marginVertical: 5,
    width: 300,
    elevation: 2,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
